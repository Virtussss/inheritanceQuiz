/**
 * 
 */
/**
 * @author jasonntnl00
 *
 */
module classLA02 {
}
package inheritanceQuiz;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter name: ");
		String name = scanner.nextLine();
		
		System.out.print("Enter birth date: ");
		String born_date = scanner.nextLine();
		
		System.out.println("Display class:");
		System.out.println("1. Person");
		System.out.println("2. Mahasiswa");
		System.out.println("3. Dosen");
		int choice = scanner.nextInt();
		
		if(choice == 1) {
			Person person = new Person(name, born_date);
			
			System.out.println("Name: " + person.name);
			System.out.println("Born date: " + person.born_date);
			person.sleep();
		}
		
		else if(choice == 2) {
			System.out.print("Enter student ID: ");
			String student_id = scanner.next();
			
			Mahasiswa mahasiswa = new Mahasiswa(name, born_date, student_id);
			
			System.out.println("Name: " + mahasiswa.name);
			System.out.println("Birth date: " + mahasiswa.born_date);
			System.out.println("Student ID: " + mahasiswa.student_id);
			System.out.println("Amount of points: " + mahasiswa.point);
			
			mahasiswa.helpingDosen();
			System.out.println("Updated points: " + mahasiswa.point);
		}
		
		else if(choice == 3) {
			System.out.print("Enter Lecturer ID: ");
			String code_dosen = scanner.next();
			
			Dosen dosen = new Dosen(name, born_date, code_dosen);
			
			dosen.point = 0;
			System.out.println("Name: " + dosen.name);
			System.out.println("Born date: " + dosen.born_date);
			System.out.println("Lecturer ID: " + dosen.code_dosen);
			System.out.println("Amount of points: " + dosen.point);
			
			System.out.println("Display lecturer's activities:");
			System.out.println("1. Self Development");
			System.out.println("2. Teaching");
			System.out.println("3. P2M");
			System.out.println("4. Research");
			System.out.println("5. Other Works");
			
			int lectureChoice = scanner.nextInt();
			
			if(lectureChoice == 1) {
				dosen.selfDev();
			}
			else if(lectureChoice == 2) {
				dosen.teach();
			}
			else if(lectureChoice == 3) {
				dosen.p2m();
			}
			else if(lectureChoice == 4) {
				dosen.research();
			}
			else if(lectureChoice == 5) {
				dosen.otherWorks();
			}
			else {
				System.out.println("Please try again.");
			}
			System.out.println("Updated points: " + dosen.point);
		}
		
		else {
			System.out.println("Invalid choice.");
		}
	}

}

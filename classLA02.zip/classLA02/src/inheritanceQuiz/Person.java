package inheritanceQuiz;

public class Person {
	String name;
	String born_date;
	
	public Person(String name, String born_date) {
		this.name = name;
		this.born_date = born_date;
	}
	
	public Person() {
		// TODO Auto-generated constructor stub
	}

	public void sleep() {
		System.out.println(name + " is sleeping.");
	}
}
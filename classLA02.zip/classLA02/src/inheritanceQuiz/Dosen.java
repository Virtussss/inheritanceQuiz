package inheritanceQuiz;

public class Dosen extends Person{
	String code_dosen;
	int point;
	
	public Dosen(String name, String born_date, String code_dosen) {
		super(name, born_date);
		this.code_dosen = code_dosen;
		this.point = 0;
	}
	
	public void selfDev() {
		point += 10;
		System.out.println("Mr/Mrs. " + name + " has finished developing themselves.");
	}
	
	public void teach() {
		point += 10;
		System.out.println("Mr/Mrs. " + name + " has taught a class.");
	}
	
	public void p2m() {
		point += 10;
		System.out.println("Mr/Mrs. " + name + " has conducted a p2m.");
	}
	
	public void research() {
		point += 10;
		System.out.println("Mr/Mrs. " + name + " has conducted a research.");
	}
	
	public void otherWorks() {
		point += 5;
		System.out.println("Mr/Mrs. " + name + " did other works.");
	}
}

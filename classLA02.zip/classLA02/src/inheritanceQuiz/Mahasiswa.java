package inheritanceQuiz;

public class Mahasiswa extends Person {
	String student_id;
	int point;
		
	public Mahasiswa(String name, String born_date, String student_id) {
		super(name, born_date);
		this.student_id = student_id;
		this.point = 0;
	}
		
	public void helpingDosen() {
		point += 10;
		System.out.println(name + " has helped a lecturer.");
	}
}
